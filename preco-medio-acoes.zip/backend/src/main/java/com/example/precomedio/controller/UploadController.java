package com.example.precomedio.controller;

import com.example.precomedio.model.Compra;
import com.example.precomedio.service.CalculadoraPrecoMedioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;

@Controller
public class UploadController {

    @Autowired
    private CalculadoraPrecoMedioService service;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file, Model model) {
        List<Compra> compras = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            String linha = br.readLine(); // cabeçalho
            while ((linha = br.readLine()) != null) {
                String[] cols = linha.split(",");
                Compra compra = new Compra(
                        LocalDate.parse(cols[0]),
                        cols[1],
                        Integer.parseInt(cols[2]),
                        Double.parseDouble(cols[3])
                );
                compras.add(compra);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Map<String, Double> resultado = service.calcularPrecoMedio(compras);
        model.addAttribute("resultados", resultado);
        return "index";
    }
}