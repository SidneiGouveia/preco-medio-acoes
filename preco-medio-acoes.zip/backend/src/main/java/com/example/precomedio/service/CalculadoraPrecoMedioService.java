package com.example.precomedio.service;

import com.example.precomedio.model.Compra;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CalculadoraPrecoMedioService {
    public Map<String, Double> calcularPrecoMedio(List<Compra> compras) {
        Map<String, Double> somaValor = new HashMap<>();
        Map<String, Integer> somaQtde = new HashMap<>();

        for (Compra c : compras) {
            somaValor.merge(c.getTicker(), c.getValorPago(), Double::sum);
            somaQtde.merge(c.getTicker(), c.getQuantidade(), Integer::sum);
        }

        return somaValor.entrySet().stream()
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                e -> e.getValue() / somaQtde.get(e.getKey())
            ));
    }
}