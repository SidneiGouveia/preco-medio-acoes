package com.example.precomedio.model;

import java.time.LocalDate;

public class Compra {
    private LocalDate data;
    private String ticker;
    private int quantidade;
    private double valorPago;

    public Compra(LocalDate data, String ticker, int quantidade, double valorPago) {
        this.data = data;
        this.ticker = ticker;
        this.quantidade = quantidade;
        this.valorPago = valorPago;
    }

    public LocalDate getData() { return data; }
    public String getTicker() { return ticker; }
    public int getQuantidade() { return quantidade; }
    public double getValorPago() { return valorPago; }
}